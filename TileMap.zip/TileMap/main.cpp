#include <iostream>
#include <SFML/Graphics.hpp>
#include <fstream>
#include <cctype>
#include <string>


int main()
{
    std::ifstream openfile("Map.txt");
    sf::Texture tileTexture;
    sf::Sprite tileSprite;

    sf::Vector2i map[100][100];
    sf::Vector2i loadCounter = sf::Vector2i(0,0);

    if(openfile.is_open())
    {
        std::string tileLocation;
        openfile >> tileLocation;

        tileTexture.loadFromFile(tileLocation);

        tileSprite.setTexture(tileTexture);

        while(!openfile.eof())
        {
            std::string str;
            openfile >> str;
            char x = str[0], y = str[2];
            if(!isdigit(x) || !isdigit(y))
            {
                map[loadCounter.x][loadCounter.y] = sf::Vector2i(-1, -1);
            } else {
                map[loadCounter.x][loadCounter.y] = sf::Vector2i(x - '0', y - '0');
            }

            if(openfile.peek() == '\n')
            {
                loadCounter.x = 0;
                loadCounter.y++;
            } else {
                loadCounter.x++;
            }
        }

        loadCounter.y++;
    }

    sf::RenderWindow Window(sf::VideoMode(640, 580, 32), "Tile Mapping");

    while(Window.isOpen())
    {
        sf::Event Event;
        while(Window.pollEvent(Event))
        {
            switch (Event.type)
            {
                case sf::Event::Closed:
                    Window.close();
                    break;
            }
        }

        Window.clear();

        for (int i = 0; i < loadCounter.x; ++i)
        {
            for (int j = 0; j < loadCounter.y; ++j)
            {
                if(map[i][j].x != -1 && map[i][j].y != -1)
                {
                    tileSprite.setPosition(i*32, j*32);
                    tileSprite.setTextureRect(sf::IntRect(map[i][j].x * 32, map[i][j].y * 32, 32, 32));
                    Window.draw(tileSprite);
                }
            }
        }

        Window.display();
    }
}